from django.apps import AppConfig


class OffersConfig(AppConfig):
    name = 'offers'

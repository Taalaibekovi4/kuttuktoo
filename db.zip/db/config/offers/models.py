from django.db import models


class SiteSettings(models.Model):
    brand_name = models.CharField(max_length=80, default="kuttuktoo", blank=True)
    subtitle = models.CharField(max_length=120, default="видео + тарифтер", blank=True)
    whatsapp_link = models.URLField(default="https://wa.me/996221000953", blank=True)
    footer_text = models.CharField(max_length=120, default="© REKLAM", blank=True)

    # ✅ Логотип меняется в админке
    logo = models.ImageField(upload_to="site/logo/", null=True, blank=True)

    def __str__(self):
        return "Site Settings"

    class Meta:
        verbose_name = "Site Settings"
        verbose_name_plural = "Site Settings"


class Offer(models.Model):
    key = models.SlugField(max_length=64, unique=True)
    title = models.CharField(max_length=120)
    sub = models.CharField(max_length=180, blank=True)
    badge = models.CharField(max_length=60, blank=True)
    price = models.CharField(max_length=40, blank=True)
    wa_text = models.CharField(max_length=255, blank=True)

    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.title} ({self.key})"

    class Meta:
        ordering = ["sort_order", "id"]


class OfferFeature(models.Model):
    offer = models.ForeignKey(Offer, on_delete=models.CASCADE, related_name="features")
    text = models.CharField(max_length=255)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return f"{self.offer.key}: {self.text}"


class OfferVideo(models.Model):
    offer = models.ForeignKey(Offer, on_delete=models.CASCADE, related_name="videos")
    file = models.FileField(upload_to="offers/videos/")
    duration = models.CharField(max_length=20, blank=True)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return f"{self.offer.key}: video#{self.id}"
